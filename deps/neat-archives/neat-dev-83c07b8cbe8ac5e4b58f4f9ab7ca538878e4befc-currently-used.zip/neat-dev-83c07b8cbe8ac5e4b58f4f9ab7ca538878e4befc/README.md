# Neat

Neat is a high-performance .NET basic utility library.
